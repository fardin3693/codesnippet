import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Download, 
  Copy, 
  Code, 
  Layers, 
  Palette, 
  Sparkles, 
  RefreshCw, 
  ChevronRight,
  FileCode,
  Upload,
  ExternalLink,
  Compass,
  SlidersHorizontal,
  Heart
} from 'lucide-react';
import { toPng, toBlob } from 'html-to-image';
import Prism from 'prismjs';

// Statically import standard Prism languages
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-rust';
import 'prismjs/components/prism-go';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-yaml';

import { 
  FONTS, 
  THEMES, 
  BACKDROPS, 
  LANGUAGES, 
  Language, 
  CodeTheme, 
  BackdropPreset, 
  FontPreset 
} from './utils/codeTemplates';

export default function App() {
  // Core Code & Syntax States
  const [code, setCode] = useState<string>(LANGUAGES[0].defaultCode);
  const [language, setLanguage] = useState<Language>(LANGUAGES[0]);
  const [theme, setTheme] = useState<CodeTheme>(THEMES[0]);
  
  // Backdrop & Styling States
  const [backdrop, setBackdrop] = useState<BackdropPreset>(BACKDROPS[0]);
  const [customGradientStart, setCustomGradientStart] = useState<string>('#c084fc');
  const [customGradientEnd, setCustomGradientEnd] = useState<string>('#6366f1');
  const [customGradientAngle, setCustomGradientAngle] = useState<number>(135);
  
  const [padding, setPadding] = useState<number>(48);
  const [borderRadius, setBorderRadius] = useState<number>(16);
  const [shadowIntensity, setShadowIntensity] = useState<number>(60); // 0 to 100
  const [showNoise, setShowNoise] = useState<boolean>(true);
  const [bgBlur, setBgBlur] = useState<number>(0); // backdrop-blur amount
  const [customBgImage, setCustomBgImage] = useState<string | null>(null);
  
  // Window Customization States
  const [macButtons, setMacButtons] = useState<boolean>(true);
  const [macButtonsStyle, setMacButtonsStyle] = useState<'classic' | 'dark' | 'light' | 'neon'>('classic');
  const [fileName, setFileName] = useState<string>('wizardry.ts');
  const [showFileName, setShowFileName] = useState<boolean>(true);
  const [lineNumbers, setLineNumbers] = useState<boolean>(true);
  const [activeLine, setActiveLine] = useState<number | null>(null);
  
  // Font & Editor States
  const [fontFamily, setFontFamily] = useState<FontPreset>(FONTS[0]);
  const [fontSize, setFontSize] = useState<number>(14);
  const [lineHeight, setLineHeight] = useState<number>(24); // px
  const [editorWidth, setEditorWidth] = useState<string>('auto'); // 'auto' | '600px' | '800px' | '1000px'
  const [activeLineHighlight, setActiveLineHighlight] = useState<boolean>(true);
  
  // Watermark Settings
  const [watermark, setWatermark] = useState<boolean>(true);
  const [watermarkText, setWatermarkText] = useState<string>('⚡ @codeglow');
  const [watermarkPosition, setWatermarkPosition] = useState<'bottom-left' | 'bottom-right'>('bottom-right');

  // 3D Tilt States
  const [is3dTiltEnabled, setIs3dTiltEnabled] = useState<boolean>(true);
  const [tiltX, setTiltX] = useState<number>(0);
  const [tiltY, setTiltY] = useState<number>(0);
  const [perspective, setPerspective] = useState<number>(1000);

  // Interactive UI & Tabs States
  const [activeTab, setActiveTab] = useState<'editor' | 'canvas' | 'window' | 'templates'>('editor');
  const [notification, setNotification] = useState<{ show: boolean; message: string; type: 'success' | 'info' | 'error' }>({
    show: false,
    message: '',
    type: 'success'
  });
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Refs
  const previewRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Automatically update file extension when language changes
  useEffect(() => {
    const parts = fileName.split('.');
    if (parts.length > 1) {
      parts[parts.length - 1] = language.extension;
      setFileName(parts.join('.'));
    } else {
      setFileName(`${fileName}.${language.extension}`);
    }
  }, [language]);

  // Highlight code reactively using Prism
  const highlightedCode = useMemo(() => {
    const langId = language.prismId;
    let prismLang = Prism.languages[langId];
    
    if (!prismLang) {
      prismLang = Prism.languages.javascript || Prism.languages.clike;
    }
    
    try {
      return Prism.highlight(code, prismLang, langId);
    } catch (err) {
      console.error("Highlighting failed:", err);
      return code;
    }
  }, [code, language]);

  // Toast Notification Helper
  const triggerNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 3500);
  };

  // Export PNG with html-to-image
  const handleDownload = async () => {
    if (!previewRef.current) return;
    setIsGenerating(true);
    triggerNotification("Preparing high-definition image...", "info");
    
    try {
      // Wait for potential state renders to complete
      await new Promise(resolve => setTimeout(resolve, 200));
      
      const dataUrl = await toPng(previewRef.current, {
        pixelRatio: 3, // Ultra crisp image
        style: {
          transform: 'none', // Reset 3D tilt on export so it renders perfectly straight
        },
        cacheBust: true,
      });
      
      const link = document.createElement('a');
      link.download = `codeglow-${language.id}-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
      triggerNotification("Image downloaded successfully! 🎨🚀", "success");
    } catch (error) {
      console.error("Export failed:", error);
      triggerNotification("Export failed. Please try again.", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy PNG image to clipboard
  const handleCopyImage = async () => {
    if (!previewRef.current) return;
    setIsGenerating(true);
    triggerNotification("Generating clip-ready image...", "info");

    try {
      await new Promise(resolve => setTimeout(resolve, 150));
      const blob = await toBlob(previewRef.current, {
        pixelRatio: 2,
        style: {
          transform: 'none',
        },
        cacheBust: true,
      });

      if (blob) {
        await navigator.clipboard.write([
          new ClipboardItem({
            [blob.type]: blob,
          }),
        ]);
        triggerNotification("Copied image to clipboard! Paste anywhere 📋✨", "success");
      }
    } catch (error) {
      console.error("Clipboard write failed:", error);
      triggerNotification("Could not copy image. Downloading instead...", "info");
      handleDownload();
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy Raw Code to Clipboard
  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    triggerNotification("Raw code copied to clipboard!", "success");
  };

  // Handle keyboard indent in raw text editor
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const { selectionStart, selectionEnd, value } = e.currentTarget;
      const newValue = value.substring(0, selectionStart) + '  ' + value.substring(selectionEnd);
      setCode(newValue);
      
      // Restore caret selection index
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = selectionStart + 2;
        }
      }, 0);
    }
  };

  // Image Upload handler for backdrop
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const dataUrl = event.target.result as string;
          setCustomBgImage(dataUrl);
          
          // Automatically switch backdrop to custom style configuration
          const customPreset: BackdropPreset = {
            id: 'custom-upload',
            name: 'Custom Uploaded Image',
            type: 'mesh',
            style: {
              backgroundImage: `url(${dataUrl})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            },
            description: 'Your custom image background'
          };
          setBackdrop(customPreset);
          triggerNotification("Custom background image loaded!", "success");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Tilt calculation on hover
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!is3dTiltEnabled) return;
    const card = e.currentTarget;
    const box = card.getBoundingClientRect();
    
    // Get center relative cursor
    const x = e.clientX - box.left - box.width / 2;
    const y = e.clientY - box.top - box.height / 2;
    
    // Standardize maximum angle limit to 14 degrees
    const maxTilt = 14;
    const calculatedTiltX = -(y / (box.height / 2)) * maxTilt;
    const calculatedTiltY = (x / (box.width / 2)) * maxTilt;
    
    setTiltX(calculatedTiltX);
    setTiltY(calculatedTiltY);
  };

  const handleMouseLeave = () => {
    setTiltX(0);
    setTiltY(0);
  };

  // Dynamic shadow configuration mapping
  const dynamicShadowStyle = useMemo(() => {
    if (shadowIntensity === 0) return 'none';
    const opacity = shadowIntensity / 100;
    const blur = Math.round(shadowIntensity * 0.8);
    const spread = Math.round(shadowIntensity * 0.15);
    
    return `0 ${blur}px ${blur * 1.5}px -${spread}px rgba(0, 0, 0, 0.7), 0 0 ${blur}px -2px ${theme.accentColor}${Math.round(opacity * 255).toString(16).padStart(2, '0')}`;
  }, [shadowIntensity, theme]);

  // Render list of lines to enable selection & line numbering
  const lineCount = code.split('\n').length;

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05021a] font-sans text-slate-200">
      
      {/* Fluid background mesh gradient animation (deep dark cosmic context) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60vw] h-[60vw] rounded-full bg-purple-900/20 blur-[140px] animate-orb-1"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[55vw] h-[55vw] rounded-full bg-blue-900/20 blur-[150px] animate-orb-2"></div>
        <div className="absolute top-[30%] right-[20%] w-[40vw] h-[40vw] rounded-full bg-pink-900/10 blur-[130px] animate-orb-3"></div>
        <div className="absolute inset-0 grid-bg opacity-45"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#030014]/10 via-transparent to-[#030014]/80"></div>
      </div>

      {/* Glowing Toast Notification */}
      <AnimatePresence>
        {notification.show && (
          <motion.div 
            initial={{ opacity: 0, y: -30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3 rounded-full border border-purple-500/35 bg-slate-950/85 backdrop-blur-xl shadow-2xl shadow-purple-500/10 text-sm"
          >
            <div className={`h-2 w-2 rounded-full ${notification.type === 'success' ? 'bg-green-400 shadow-[0_0_8px_#4ade80]' : notification.type === 'error' ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]' : 'bg-cyan-400 shadow-[0_0_8px_#22d3ee]'}`} />
            <span className="font-medium tracking-wide">{notification.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Premium Glassmorphism Top Header */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-slate-950/55 backdrop-blur-md py-4 px-6 sm:px-12 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 via-violet-600 to-indigo-700 shadow-lg shadow-indigo-500/35 overflow-hidden">
            <Sparkles className="h-5 w-5 text-white animate-pulse" />
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/25 to-transparent opacity-40 rotate-45"></div>
          </div>
          <div>
            <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-purple-200 to-indigo-400 bg-clip-text text-transparent">
              CodeGlow
            </span>
            <span className="ml-2 text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border border-purple-500/30 bg-purple-500/10 text-purple-300 tracking-widest">
              PRO
            </span>
          </div>
        </div>

        {/* Export Actions Header Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <button 
            onClick={handleCopyCode}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-white/5 bg-white/5 hover:bg-white/10 text-sm font-medium text-slate-300 hover:text-white transition active:scale-95"
          >
            <Code className="h-4 w-4 text-purple-400" />
            <span>Copy Code</span>
          </button>

          <button 
            onClick={handleCopyImage}
            disabled={isGenerating}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-purple-500/20 bg-purple-600/15 hover:bg-purple-600/25 text-sm font-medium text-purple-200 hover:text-white transition active:scale-95 disabled:opacity-50"
          >
            <Copy className="h-4 w-4 text-purple-300" />
            <span>Copy Image</span>
          </button>

          <button 
            onClick={handleDownload}
            disabled={isGenerating}
            className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-sm font-semibold text-white shadow-md shadow-purple-900/30 transition active:scale-95 hover:shadow-purple-600/20 disabled:opacity-50"
          >
            <Download className="h-4 w-4" />
            <span>Export PNG</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <main className="relative z-10 min-h-[calc(100vh-72px)] px-4 py-6 sm:px-8 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-[1800px] mx-auto">
        
        {/* LEFT / CENTER: The Interactive Code Canvas Workspace */}
        <div className="lg:col-span-8 flex flex-col gap-6 items-center justify-center w-full">
          
          {/* Quick Aspect Ratio / Screen Size Helpers */}
          <div className="flex items-center justify-between w-full px-2 py-1.5 rounded-xl bg-white/[0.02] border border-white/5 backdrop-blur-sm text-xs text-slate-400">
            <div className="flex items-center gap-4">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Compass className="h-3.5 w-3.5 text-purple-400" /> Workspace Canvas
              </span>
              <span className="h-4 w-[1px] bg-white/10"></span>
              <div className="flex items-center gap-2">
                <span>Width:</span>
                <div className="inline-flex rounded-lg bg-slate-950 p-0.5 border border-white/5">
                  {(['auto', '600px', '800px', '1000px'] as const).map((w) => (
                    <button
                      key={w}
                      onClick={() => setEditorWidth(w)}
                      className={`px-2 py-1 rounded-md text-[11px] font-medium transition-all ${editorWidth === w ? 'bg-purple-600 text-white shadow-sm' : 'hover:text-white'}`}
                    >
                      {w === 'auto' ? 'Auto' : w}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-3">
              <button 
                onClick={() => {
                  setCode(language.defaultCode);
                  setPadding(48);
                  setBorderRadius(16);
                  setShadowIntensity(60);
                  setIs3dTiltEnabled(true);
                  setBgBlur(0);
                }}
                className="hover:text-white flex items-center gap-1 hover:underline transition"
              >
                <RefreshCw className="h-3 w-3 text-purple-400" /> Reset Template
              </button>
            </div>
          </div>

          {/* Canvas Element to Capture */}
          <div 
            className="w-full overflow-visible py-8 px-4 flex items-center justify-center"
            style={{ perspective: `${perspective}px` }}
          >
            <motion.div
              ref={previewRef}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              animate={{ 
                rotateX: is3dTiltEnabled ? tiltX : 0, 
                rotateY: is3dTiltEnabled ? tiltY : 0,
              }}
              transition={{ type: "spring", damping: 25, stiffness: 250, mass: 0.5 }}
              className="relative flex items-center justify-center transition-all duration-300 noise-bg w-full bg-transparent"
              style={{
                padding: `${padding}px`,
                borderRadius: `${borderRadius}px`,
                maxWidth: editorWidth === 'auto' ? '100%' : editorWidth,
                boxShadow: '0 30px 80px -20px rgba(0, 0, 0, 0.6)',
              }}
            >
              {/* Absolute Background Layer with dynamic style preset */}
              <div 
                className="absolute inset-0 -z-10 rounded-[inherit] transition-all duration-300" 
                style={{ 
                  ...(backdrop.id === 'custom-upload' && customBgImage
                    ? { backgroundImage: `url(${customBgImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }
                    : backdrop.id === 'custom-gradient'
                    ? { backgroundImage: `linear-gradient(${customGradientAngle}deg, ${customGradientStart}, ${customGradientEnd})` }
                    : backdrop.style
                  ),
                  ...(bgBlur > 0 ? { filter: `blur(${bgBlur}px)` } : {})
                }}
              />

              {/* Noise pattern overlay for aesthetic texture */}
              {showNoise && (
                <div className="absolute inset-0 -z-10 rounded-[inherit] pointer-events-none opacity-[0.08] dot-bg mix-blend-overlay" />
              )}

              {/* THE DYNAMIC SYNTAX WINDOW */}
              <div
                className={`relative w-full overflow-hidden code-window ${theme.class} transition-all duration-300`}
                style={{
                  backgroundColor: theme.bgColor,
                  color: theme.textColor,
                  borderRadius: `${Math.max(4, borderRadius - 4)}px`,
                  boxShadow: dynamicShadowStyle,
                  border: '1px solid rgba(255, 255, 255, 0.12)'
                }}
              >
                {/* Style declaration tag inside the canvas so html-to-image embeds fonts correctly */}
                <style dangerouslySetInnerHTML={{ __html: `
                  .code-window pre, .code-window textarea {
                    ${fontFamily.css}
                    font-size: ${fontSize}px;
                    line-height: ${lineHeight}px;
                  }
                `}} />

                {/* Windows / MacOS style top bar header */}
                <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06] bg-black/10">
                  
                  {/* macOS Windows Style Dots */}
                  {macButtons && (
                    <div className="flex items-center gap-2">
                      {macButtonsStyle === 'classic' && (
                        <>
                          <span className="h-3.5 w-3.5 rounded-full bg-[#ff5f56] inline-block border border-red-600/30" />
                          <span className="h-3.5 w-3.5 rounded-full bg-[#ffbd2e] inline-block border border-yellow-600/30" />
                          <span className="h-3.5 w-3.5 rounded-full bg-[#27c93f] inline-block border border-green-600/30" />
                        </>
                      )}
                      {macButtonsStyle === 'dark' && (
                        <>
                          <span className="h-3.5 w-3.5 rounded-full bg-white/10 inline-block border border-white/10" />
                          <span className="h-3.5 w-3.5 rounded-full bg-white/10 inline-block border border-white/10" />
                          <span className="h-3.5 w-3.5 rounded-full bg-white/10 inline-block border border-white/10" />
                        </>
                      )}
                      {macButtonsStyle === 'light' && (
                        <>
                          <span className="h-3.5 w-3.5 rounded-full bg-white/20 inline-block border border-white/20" />
                          <span className="h-3.5 w-3.5 rounded-full bg-white/20 inline-block border border-white/20" />
                          <span className="h-3.5 w-3.5 rounded-full bg-white/20 inline-block border border-white/20" />
                        </>
                      )}
                      {macButtonsStyle === 'neon' && (
                        <>
                          <span className="h-3.5 w-3.5 rounded-full bg-purple-500/40 shadow-[0_0_6px_rgba(168,85,247,0.5)] inline-block border border-purple-400/30" />
                          <span className="h-3.5 w-3.5 rounded-full bg-pink-500/40 shadow-[0_0_6px_rgba(236,72,153,0.5)] inline-block border border-pink-400/30" />
                          <span className="h-3.5 w-3.5 rounded-full bg-blue-500/40 shadow-[0_0_6px_rgba(59,130,246,0.5)] inline-block border border-blue-400/30" />
                        </>
                      )}
                    </div>
                  )}

                  {/* Editable Window File Name Tab */}
                  {showFileName ? (
                    <div className="absolute left-1/2 transform -translate-x-1/2 max-w-[200px] sm:max-w-[300px] flex items-center gap-2 px-3 py-1 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                      <FileCode className="h-3.5 w-3.5 text-purple-400 shrink-0" />
                      <input
                        type="text"
                        value={fileName}
                        onChange={(e) => setFileName(e.target.value)}
                        className="bg-transparent text-xs font-medium text-slate-300 focus:text-white outline-none border-none w-full text-center cursor-text focus:bg-white/5 rounded px-1 transition"
                        title="Rename snippet file"
                      />
                    </div>
                  ) : (
                    <div className="w-1" />
                  )}

                  {/* Language tag helper */}
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.06] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                    <div className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: theme.accentColor }} />
                    {language.name}
                  </div>
                </div>

                {/* Interactive Edit Canvas & Display Layer */}
                <div className="relative w-full p-6 flex select-text overflow-hidden">
                  
                  {/* Dynamic Active Line highlight glow background bar */}
                  {activeLineHighlight && activeLine !== null && (
                    <div 
                      className="absolute left-0 right-0 pointer-events-none transition-all duration-200"
                      style={{
                        top: `${activeLine * lineHeight + 24}px`, // 24px accounts for parent padding (p-6)
                        height: `${lineHeight}px`,
                        backgroundColor: 'rgba(255, 255, 255, 0.04)',
                        borderLeft: `3px solid ${theme.accentColor}`
                      }}
                    />
                  )}

                  {/* Line numbers Column */}
                  {lineNumbers && (
                    <div 
                      className="flex flex-col select-none text-right pr-4 border-r border-white/[0.05] mr-4 font-mono text-xs opacity-35 tracking-tight shrink-0"
                      style={{ 
                        lineHeight: `${lineHeight}px`,
                        fontSize: `${fontSize}px` 
                      }}
                    >
                      {Array.from({ length: lineCount }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setActiveLine(activeLine === i ? null : i)}
                          className={`cursor-pointer hover:text-white hover:opacity-100 transition-all outline-none ${activeLine === i ? 'text-purple-400 font-bold opacity-100 scale-110' : ''}`}
                          style={{ height: `${lineHeight}px` }}
                          title="Click to highlight this line"
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Text Editor Double Layer: Raw input on top, syntax highlighted code underneath */}
                  <div className="relative flex-1 overflow-visible min-h-[120px]">
                    {/* Preformatted block containing syntax highlighted representation */}
                    <pre 
                      className="absolute inset-0 m-0 p-0 pointer-events-none overflow-visible select-none bg-transparent"
                      style={{ 
                        lineHeight: `${lineHeight}px`,
                        fontSize: `${fontSize}px`,
                        whiteSpace: 'pre',
                        fontFamily: 'inherit'
                      }}
                    >
                      <code 
                        className={`language-${language.prismId} block overflow-visible bg-transparent`}
                        dangerouslySetInnerHTML={{ __html: highlightedCode }}
                      />
                    </pre>

                    {/* Hidden (but selectable & editable) transparent Textarea Overlay */}
                    <textarea
                      ref={textareaRef}
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      onKeyDown={handleKeyDown}
                      spellCheck={false}
                      autoCapitalize="none"
                      autoComplete="off"
                      autoCorrect="off"
                      className="absolute inset-0 w-full h-full m-0 p-0 bg-transparent border-none outline-none resize-none text-transparent caret-purple-400 overflow-visible select-text whitespace-pre font-mono"
                      style={{
                        fontFamily: 'inherit',
                        fontSize: `${fontSize}px`,
                        lineHeight: `${lineHeight}px`,
                      }}
                    />
                  </div>
                </div>

                {/* Aesthetic Watermark inside card */}
                {watermark && (
                  <div 
                    className={`flex items-center gap-1.5 px-3 py-1.5 border-t border-white/[0.04] bg-black/15 select-none text-[11px] font-medium tracking-wide opacity-55 ${
                      watermarkPosition === 'bottom-left' ? 'justify-start' : 'justify-end'
                    }`}
                  >
                    <span>{watermarkText}</span>
                  </div>
                )}
              </div>
            </motion.div>
          </div>

          {/* Aesthetic Tips / Controls under Canvas */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full px-4 py-3 rounded-xl border border-white/5 bg-slate-950/30 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] font-semibold text-purple-400">💡 Pro Tip</span>
              <span>Double-click/click directly inside the snippet code block to live edit raw code.</span>
            </div>
            <div className="flex items-center gap-1 shrink-0 text-[11px]">
              <span>Highlight specific rows by clicking the line numbers.</span>
            </div>
          </div>

        </div>

        {/* RIGHT: The Glassmorphic Control Sidebar */}
        <div className="lg:col-span-4 w-full">
          
          {/* Sidebar main wrap */}
          <div className="sticky top-24 glass-panel rounded-2xl overflow-hidden shadow-2xl shadow-black/50 border border-white/10">
            
            {/* Glass Sidebar Header with controls icon */}
            <div className="px-6 py-5 border-b border-white/5 bg-slate-950/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4 text-purple-400" />
                <h2 className="font-bold tracking-tight text-slate-100 text-base">Studio Customizer</h2>
              </div>
              <span className="text-[11px] font-medium bg-purple-600/25 border border-purple-500/35 px-2.5 py-1 rounded-full text-purple-200 animate-pulse">
                Real-time Render
              </span>
            </div>

            {/* Section Tabs */}
            <div className="grid grid-cols-4 border-b border-white/5 bg-slate-950/20 text-center">
              {[
                { id: 'editor', label: 'Editor', icon: Code },
                { id: 'canvas', label: 'Backdrop', icon: Palette },
                { id: 'window', label: 'Window', icon: Layers },
                { id: 'templates', label: 'Samples', icon: Compass },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex flex-col items-center gap-1 py-3 text-xs font-medium border-b-2 transition ${
                      activeTab === tab.id 
                        ? 'border-purple-500 text-purple-400 bg-white/[0.02]' 
                        : 'border-transparent text-slate-400 hover:text-white hover:bg-white/[0.01]'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span className="text-[10px] tracking-tight">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab Content Container */}
            <div className="p-6 max-h-[calc(100vh-360px)] overflow-y-auto">
              
              {/* TAB 1: EDITOR & STYLES */}
              {activeTab === 'editor' && (
                <div className="flex flex-col gap-5">
                  
                  {/* Theme Selector */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                      <span>Syntax Theme</span>
                      <span className="text-[10px] text-slate-500">Updates code window</span>
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {THEMES.map((t) => (
                        <button
                          key={t.id}
                          onClick={() => setTheme(t)}
                          className={`flex items-center justify-between p-2.5 rounded-xl border text-left text-xs transition ${
                            theme.id === t.id
                              ? 'border-purple-500 bg-purple-600/10 text-white font-semibold'
                              : 'border-white/5 bg-white/[0.02] hover:bg-white/5 text-slate-300'
                          }`}
                        >
                          <span>{t.name}</span>
                          <div className="h-2.5 w-2.5 rounded-full border border-black/20" style={{ backgroundColor: t.accentColor }} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Programming Language Selector */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300">Programming Language</label>
                    <select
                      value={language.id}
                      onChange={(e) => {
                        const selected = LANGUAGES.find(l => l.id === e.target.value);
                        if (selected) {
                          setLanguage(selected);
                          setCode(selected.defaultCode);
                          triggerNotification(`Loaded ${selected.name} Template`, "info");
                        }
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-white/10 bg-slate-950 text-sm font-medium text-slate-300 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition"
                    >
                      {LANGUAGES.map((lang) => (
                        <option key={lang.id} value={lang.id}>
                          {lang.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Font Family */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300">Font Family</label>
                    <div className="grid grid-cols-2 gap-2">
                      {FONTS.map((f) => (
                        <button
                          key={f.id}
                          onClick={() => setFontFamily(f)}
                          className={`px-3 py-2 rounded-xl border text-xs transition text-center ${
                            fontFamily.id === f.id
                              ? 'border-purple-500 bg-purple-600/10 text-white font-semibold'
                              : 'border-white/5 bg-white/[0.02] hover:bg-white/5 text-slate-400 hover:text-white'
                          }`}
                        >
                          {f.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Font Size Slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Font Size</span>
                      <span className="text-purple-400">{fontSize}px</span>
                    </div>
                    <input
                      type="range"
                      min="12"
                      max="22"
                      step="1"
                      value={fontSize}
                      onChange={(e) => setFontSize(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Line Height Slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Line Height</span>
                      <span className="text-purple-400">{lineHeight}px</span>
                    </div>
                    <input
                      type="range"
                      min="20"
                      max="36"
                      step="1"
                      value={lineHeight}
                      onChange={(e) => setLineHeight(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Active Line Highlight Toggle */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">Highlight Hovered Line</span>
                      <span className="text-[10px] text-slate-500">Gives background emphasis</span>
                    </div>
                    <button
                      onClick={() => setActiveLineHighlight(!activeLineHighlight)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        activeLineHighlight ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          activeLineHighlight ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                </div>
              )}

              {/* TAB 2: CANVAS & BACKDROP */}
              {activeTab === 'canvas' && (
                <div className="flex flex-col gap-5">
                  
                  {/* Backdrop Preset selection */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300">Backdrop Theme</label>
                    <div className="grid grid-cols-2 gap-2">
                      {BACKDROPS.map((preset) => (
                        <button
                          key={preset.id}
                          onClick={() => setBackdrop(preset)}
                          className={`flex flex-col items-start p-2.5 rounded-xl border text-left transition ${
                            backdrop.id === preset.id
                              ? 'border-purple-500 bg-purple-600/10'
                              : 'border-white/5 bg-white/[0.02] hover:bg-white/5'
                          }`}
                        >
                          <span className="text-xs font-semibold text-slate-200">{preset.name}</span>
                          <span className="text-[9px] text-slate-500 line-clamp-1">{preset.description}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Gradient pickers */}
                  <div className="flex flex-col gap-3 p-4.5 rounded-2xl border border-white/5 bg-slate-950/40">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-300">Custom Gradient Builder</span>
                      <button
                        onClick={() => {
                          const customPreset: BackdropPreset = {
                            id: 'custom-gradient',
                            name: 'Custom Gradient',
                            type: 'gradient',
                            style: {},
                            description: 'Your dynamic personalized style configuration'
                          };
                          setBackdrop(customPreset);
                          triggerNotification("Custom Gradient activated!", "info");
                        }}
                        className={`px-2.5 py-1 rounded-md text-[10px] font-semibold tracking-wider uppercase transition ${
                          backdrop.id === 'custom-gradient' ? 'bg-purple-600 text-white' : 'bg-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        Activate
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="flex flex-col gap-1.5">
                        <span className="text-[10px] text-slate-500">Start Color</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={customGradientStart}
                            onChange={(e) => {
                              setCustomGradientStart(e.target.value);
                              setBackdrop(prev => ({
                                ...prev,
                                id: 'custom-gradient',
                                name: 'Custom Gradient',
                                type: 'gradient',
                                style: {}
                              }));
                            }}
                            className="h-8 w-8 rounded-lg border border-white/15 bg-transparent cursor-pointer shrink-0"
                          />
                          <input 
                            type="text"
                            value={customGradientStart}
                            onChange={(e) => setCustomGradientStart(e.target.value)}
                            className="bg-slate-950 border border-white/10 rounded px-2 py-1 text-xs text-slate-300 w-full"
                          />
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5">
                        <span className="text-[10px] text-slate-500">End Color</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={customGradientEnd}
                            onChange={(e) => {
                              setCustomGradientEnd(e.target.value);
                              setBackdrop(prev => ({
                                ...prev,
                                id: 'custom-gradient',
                                name: 'Custom Gradient',
                                type: 'gradient',
                                style: {}
                              }));
                            }}
                            className="h-8 w-8 rounded-lg border border-white/15 bg-transparent cursor-pointer shrink-0"
                          />
                          <input 
                            type="text"
                            value={customGradientEnd}
                            onChange={(e) => setCustomGradientEnd(e.target.value)}
                            className="bg-slate-950 border border-white/10 rounded px-2 py-1 text-xs text-slate-300 w-full"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Gradient Angle Slider */}
                    <div className="flex flex-col gap-1.5 mt-2">
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>Gradient Angle</span>
                        <span>{customGradientAngle}°</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="360"
                        step="5"
                        value={customGradientAngle}
                        onChange={(e) => setCustomGradientAngle(Number(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  </div>

                  {/* Custom Image Upload */}
                  <div className="flex flex-col gap-2">
                    <label className="text-xs font-semibold text-slate-300">Custom Backdrop Image</label>
                    <div className="flex items-center justify-between gap-4 p-3 rounded-xl border border-white/5 bg-white/[0.01]">
                      <span className="text-xs text-slate-400 truncate">
                        {customBgImage ? "Custom image uploaded" : "No file selected"}
                      </span>
                      <label className="relative cursor-pointer bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition inline-flex items-center gap-1.5 shrink-0">
                        <Upload className="h-3.5 w-3.5 text-purple-400" />
                        <span>Choose File</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Padding Slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Padding</span>
                      <span className="text-purple-400">{padding}px</span>
                    </div>
                    <input
                      type="range"
                      min="16"
                      max="128"
                      step="8"
                      value={padding}
                      onChange={(e) => setPadding(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Border Radius Slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Border Radius</span>
                      <span className="text-purple-400">{borderRadius}px</span>
                    </div>
                    <input
                      type="range"
                      min="4"
                      max="32"
                      step="2"
                      value={borderRadius}
                      onChange={(e) => setBorderRadius(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Drop Shadow & Neon Glow Intensity */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Neon Shadow Intensity</span>
                      <span className="text-purple-400">{shadowIntensity}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      step="5"
                      value={shadowIntensity}
                      onChange={(e) => setShadowIntensity(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Noise Overlay Switch */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">Noise/Grain Overlay</span>
                      <span className="text-[10px] text-slate-500">Adds analog film texture</span>
                    </div>
                    <button
                      onClick={() => setShowNoise(!showNoise)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        showNoise ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          showNoise ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Backdrop Blur Slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-300">
                      <span>Backdrop Blur filter</span>
                      <span className="text-purple-400">{bgBlur}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="20"
                      step="2"
                      value={bgBlur}
                      onChange={(e) => setBgBlur(Number(e.target.value))}
                      className="w-full"
                    />
                  </div>

                </div>
              )}

              {/* TAB 3: WINDOW DECORATIONS */}
              {activeTab === 'window' && (
                <div className="flex flex-col gap-5">
                  
                  {/* MacOS dots switch */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">macOS Action Dots</span>
                      <span className="text-[10px] text-slate-500">Red, Yellow, Green controls</span>
                    </div>
                    <button
                      onClick={() => setMacButtons(!macButtons)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        macButtons ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          macButtons ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* MacOS dot style style choices */}
                  {macButtons && (
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-semibold text-slate-300">Dots Color Scheme</label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { id: 'classic', name: 'Classic Color' },
                          { id: 'dark', name: 'Mono Outline' },
                          { id: 'light', name: 'Frost White' },
                          { id: 'neon', name: 'Cyber Glow' }
                        ].map((style) => (
                          <button
                            key={style.id}
                            onClick={() => setMacButtonsStyle(style.id as any)}
                            className={`px-2.5 py-2 rounded-xl border text-xs transition ${
                              macButtonsStyle === style.id
                                ? 'border-purple-500 bg-purple-600/10 text-white font-medium'
                                : 'border-white/5 bg-white/[0.02] text-slate-400 hover:text-white'
                            }`}
                          >
                            {style.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Window Title switch */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">Header Tab / File Name</span>
                      <span className="text-[10px] text-slate-500">Displays title centered</span>
                    </div>
                    <button
                      onClick={() => setShowFileName(!showFileName)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        showFileName ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          showFileName ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Line Numbers switch */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">Line Numbers</span>
                      <span className="text-[10px] text-slate-500">Display vertical code index</span>
                    </div>
                    <button
                      onClick={() => setLineNumbers(!lineNumbers)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        lineNumbers ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          lineNumbers ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* 3D Tilt feature switch */}
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-xs font-semibold text-slate-300">Interactive 3D Mouse Tilt</span>
                      <span className="text-[10px] text-slate-500">Card floats in space on hover</span>
                    </div>
                    <button
                      onClick={() => setIs3dTiltEnabled(!is3dTiltEnabled)}
                      className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        is3dTiltEnabled ? 'bg-purple-600' : 'bg-slate-800'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          is3dTiltEnabled ? 'translate-x-4.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* 3D Tilt Perspective slider */}
                  {is3dTiltEnabled && (
                    <div className="flex flex-col gap-2">
                      <div className="flex justify-between text-xs font-semibold text-slate-300">
                        <span>3D Perspective Depth</span>
                        <span className="text-purple-400">{perspective}px</span>
                      </div>
                      <input
                        type="range"
                        min="500"
                        max="2000"
                        step="50"
                        value={perspective}
                        onChange={(e) => setPerspective(Number(e.target.value))}
                        className="w-full"
                      />
                    </div>
                  )}

                  {/* Watermark section */}
                  <div className="flex flex-col gap-3 p-4 rounded-2xl border border-white/5 bg-slate-950/40">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-300">Watermark Badge</span>
                      <button
                        onClick={() => setWatermark(!watermark)}
                        className={`relative inline-flex h-5.5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          watermark ? 'bg-purple-600' : 'bg-slate-800'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4.5 w-4.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                            watermark ? 'translate-x-4.5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {watermark && (
                      <div className="flex flex-col gap-2 mt-1.5">
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] text-slate-500">Badge Text</span>
                          <input
                            type="text"
                            value={watermarkText}
                            onChange={(e) => setWatermarkText(e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg border border-white/10 bg-slate-950 text-xs text-slate-200 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition"
                          />
                        </div>

                        <div className="flex flex-col gap-1 mt-1">
                          <span className="text-[10px] text-slate-500">Position</span>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              { id: 'bottom-left', name: 'Left' },
                              { id: 'bottom-right', name: 'Right' }
                            ].map((pos) => (
                              <button
                                key={pos.id}
                                onClick={() => setWatermarkPosition(pos.id as any)}
                                className={`px-2 py-1 rounded-md border text-[10px] transition ${
                                  watermarkPosition === pos.id
                                    ? 'border-purple-500 bg-purple-600/10 text-white'
                                    : 'border-white/5 bg-slate-950 text-slate-400'
                                }`}
                              >
                                {pos.name}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                </div>
              )}

              {/* TAB 4: PREMADE TEMPLATES */}
              {activeTab === 'templates' && (
                <div className="flex flex-col gap-4">
                  
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs font-semibold text-slate-300">Premade Code Blueprints</span>
                    <span className="text-[10px] text-slate-500">Instantly load clean showcase code</span>
                  </div>

                  <div className="flex flex-col gap-2.5">
                    {LANGUAGES.map((lang) => (
                      <button
                        key={lang.id}
                        onClick={() => {
                          setLanguage(lang);
                          setCode(lang.defaultCode);
                          triggerNotification(`Loaded ${lang.name} snippet`, "success");
                        }}
                        className="flex items-center justify-between p-3 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.04] text-left transition hover:border-purple-500/30 group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-300 group-hover:bg-purple-500 group-hover:text-white transition">
                            <Code className="h-4 w-4" />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-200 block">{lang.name} snippet</span>
                            <span className="text-[9px] text-slate-500 block uppercase tracking-widest">.{lang.extension}</span>
                          </div>
                        </div>
                        <ChevronRight className="h-4 w-4 text-slate-600 group-hover:text-purple-400 transition group-hover:translate-x-0.5" />
                      </button>
                    ))}
                  </div>

                </div>
              )}

            </div>

            {/* Sidebar Footer / Branding */}
            <div className="p-5 border-t border-white/5 bg-slate-950/40 flex flex-col items-center justify-center gap-2 text-center">
              <div className="flex items-center gap-1 text-xs text-slate-400 font-medium">
                <span>Developed with</span>
                <Heart className="h-3 w-3 text-rose-500 fill-rose-500" />
                <span>for creators</span>
              </div>
              <p className="text-[10px] text-slate-600">
                CodeGlow runs entirely locally in your browser.
              </p>
            </div>

          </div>

        </div>

      </main>

      {/* Glowing futuristic web application footer section */}
      <footer className="border-t border-white/5 bg-slate-950/75 backdrop-blur-lg py-12 px-6 sm:px-12 mt-12 relative z-10">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          
          {/* Branding Column */}
          <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <div className="h-7 w-7 rounded-lg bg-purple-600 flex items-center justify-center text-white font-bold text-xs">
                CG
              </div>
              <span className="text-md font-extrabold text-white tracking-tight">CodeGlow</span>
            </div>
            <p className="text-xs text-slate-500 max-w-[320px] text-center md:text-left">
              The premium open-source code snippet visualizer designed to create high-quality showcase graphics for presentations, guides, and social media posts.
            </p>
          </div>

          {/* Features Row */}
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6 text-xs">
            <div className="flex flex-col gap-2">
              <span className="font-semibold text-slate-400">Visuals</span>
              <a href="#themes" onClick={() => { setActiveTab('canvas'); }} className="text-slate-500 hover:text-purple-400 transition">Mesh Gradients</a>
              <a href="#effects" onClick={() => { setActiveTab('canvas'); }} className="text-slate-500 hover:text-purple-400 transition">Backdrop Blurs</a>
              <a href="#noise" onClick={() => { setActiveTab('canvas'); }} className="text-slate-500 hover:text-purple-400 transition">Film Noise texture</a>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-semibold text-slate-400">Features</span>
              <a href="#numbers" onClick={() => { setActiveTab('window'); }} className="text-slate-500 hover:text-purple-400 transition">Line Numbers</a>
              <a href="#tilt" onClick={() => { setActiveTab('window'); }} className="text-slate-500 hover:text-purple-400 transition">3D Interactive Tilt</a>
              <a href="#watermark" onClick={() => { setActiveTab('window'); }} className="text-slate-500 hover:text-purple-400 transition">Watermark Branding</a>
            </div>
            <div className="flex flex-col gap-2">
              <span className="font-semibold text-slate-400">Community</span>
              <a href="https://github.com" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-purple-400 transition flex items-center gap-1">
                {/* Custom GitHub SVG */}
                <svg className="h-3.5 w-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
                </svg>
                <span>GitHub Repository</span> 
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-purple-400 transition flex items-center gap-1">
                {/* Custom Twitter/X SVG */}
                <svg className="h-3 w-3 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
                <span>Twitter Studio</span> 
                <ExternalLink className="h-2.5 w-2.5" />
              </a>
            </div>
          </div>

          {/* Bottom Actions / Social Info */}
          <div className="flex flex-col items-center md:items-end gap-3">
            <div className="flex items-center gap-3">
              <a 
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 w-9 rounded-full border border-white/5 bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 hover:text-white transition"
                title="Share on Twitter"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
              <a 
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-9 w-9 rounded-full border border-white/5 bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-300 hover:text-white transition"
                title="Star on GitHub"
              >
                <svg className="h-4 w-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
                </svg>
              </a>
            </div>
            <span className="text-[10px] text-slate-600">
              © 2026 CodeGlow. MIT Licensed. Made by developers, for developers.
            </span>
          </div>

        </div>
      </footer>

    </div>
  );
}
