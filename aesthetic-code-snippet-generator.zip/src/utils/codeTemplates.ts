import React from 'react';

export interface Language {
  id: string;
  name: string;
  prismId: string;
  extension: string;
  defaultCode: string;
}

export interface CodeTheme {
  id: string;
  name: string;
  class: string;
  bgColor: string;
  textColor: string;
  accentColor: string;
  description: string;
}

export interface BackdropPreset {
  id: string;
  name: string;
  type: 'gradient' | 'solid' | 'mesh' | 'transparent';
  style: React.CSSProperties;
  description: string;
}

export interface FontPreset {
  id: string;
  name: string;
  css: string;
}

export const FONTS: FontPreset[] = [
  { id: 'jetbrains', name: 'JetBrains Mono', css: "font-family: 'JetBrains Mono', monospace;" },
  { id: 'firacode', name: 'Fira Code', css: "font-family: 'Fira Code', monospace;" },
  { id: 'spacemono', name: 'Space Mono', css: "font-family: 'Space Mono', monospace;" },
  { id: 'sourcecode', name: 'Source Code Pro', css: "font-family: 'Source Code Pro', monospace;" },
  { id: 'ibmplex', name: 'IBM Plex Mono', css: "font-family: 'IBM Plex Mono', monospace;" },
  { id: 'comicneue', name: 'Comic Neue (Fun)', css: "font-family: 'Comic Neue', cursive;" }
];

export const THEMES: CodeTheme[] = [
  {
    id: 'dracula',
    name: 'Dracula',
    class: 'theme-dracula',
    bgColor: '#282a36',
    textColor: '#f8f8f2',
    accentColor: '#bd93f9',
    description: 'Vampire dark mode favorite'
  },
  {
    id: 'onedark',
    name: 'One Dark Pro',
    class: 'theme-onedark',
    bgColor: '#282c34',
    textColor: '#abb2bf',
    accentColor: '#61afef',
    description: 'Classic Atom-inspired palette'
  },
  {
    id: 'monokai',
    name: 'Monokai',
    class: 'theme-monokai',
    bgColor: '#272822',
    textColor: '#f8f8f2',
    accentColor: '#f92672',
    description: 'High-contrast retro classic'
  },
  {
    id: 'nord',
    name: 'Nord',
    class: 'theme-nord',
    bgColor: '#2e3440',
    textColor: '#d8dee9',
    accentColor: '#88c0d0',
    description: 'Elegant arctic-cool design'
  },
  {
    id: 'synthwave',
    name: "Synthwave '84",
    class: 'theme-synthwave',
    bgColor: '#2b213a',
    textColor: '#f0efe6',
    accentColor: '#ff7edb',
    description: 'Neon-drenched 80s cyberpunk glow'
  },
  {
    id: 'tokyonight',
    name: 'Tokyo Night',
    class: 'theme-tokyonight',
    bgColor: '#1a1b26',
    textColor: '#a9b1d6',
    accentColor: '#7aa2f7',
    description: 'Cool, glowing midnight aesthetics'
  },
  {
    id: 'cyberpunk',
    name: 'Neon Cyberpunk',
    class: 'theme-cyberpunk',
    bgColor: '#120416',
    textColor: '#e2e8f0',
    accentColor: '#ff007f',
    description: 'Vibrant high-contrast cyber-matrix'
  },
  {
    id: 'githubdark',
    name: 'GitHub Dark',
    class: 'theme-githubdark',
    bgColor: '#0d1117',
    textColor: '#c9d1d9',
    accentColor: '#58a6ff',
    description: 'Standard GitHub dark profile UI'
  },
  {
    id: 'solarized',
    name: 'Solarized Dark',
    class: 'theme-solarized',
    bgColor: '#002b36',
    textColor: '#839496',
    accentColor: '#2aa198',
    description: 'Precision contrast teal classic'
  },
  {
    id: 'panda',
    name: 'Panda',
    class: 'theme-panda',
    bgColor: '#292a2b',
    textColor: '#e6e6e6',
    accentColor: '#ff75b5',
    description: 'Cute, high-contrast pastel tones'
  }
];

export const BACKDROPS: BackdropPreset[] = [
  {
    id: 'mesh-cosmic',
    name: 'Cosmic Nebula (Mesh)',
    type: 'mesh',
    style: {
      backgroundImage: 'radial-gradient(at 0% 0%, hsla(253,16%,7%,1) 0, transparent 50%), radial-gradient(at 50% 0%, hsla(225,39%,30%,1) 0, transparent 50%), radial-gradient(at 100% 0%, hsla(339,49%,30%,1) 0, transparent 50%), radial-gradient(at 0% 100%, hsla(339,49%,30%,1) 0, transparent 50%), radial-gradient(at 50% 100%, hsla(253,16%,7%,1) 0, transparent 50%), radial-gradient(at 100% 100%, hsla(225,39%,30%,1) 0, transparent 50%)',
      backgroundColor: '#06040d'
    },
    description: 'Deep purples, cosmic blues, and hot magenta meshes'
  },
  {
    id: 'mesh-aurora',
    name: 'Northern Lights (Mesh)',
    type: 'mesh',
    style: {
      backgroundImage: 'radial-gradient(at 20% 20%, hsla(168,75%,25%,1) 0, transparent 60%), radial-gradient(at 80% 20%, hsla(204,70%,20%,1) 0, transparent 60%), radial-gradient(at 40% 80%, hsla(280,60%,20%,1) 0, transparent 70%), radial-gradient(at 80% 80%, hsla(140,65%,22%,1) 0, transparent 60%)',
      backgroundColor: '#050914'
    },
    description: 'Boreal forest emerald glows and deep space indigo'
  },
  {
    id: 'gradient-sunset',
    name: 'Cyber Sunset',
    type: 'gradient',
    style: {
      backgroundImage: 'linear-gradient(135deg, #f43f5e 0%, #c084fc 40%, #6366f1 100%)'
    },
    description: 'Hot pink to purple and bright blue'
  },
  {
    id: 'gradient-ocean',
    name: 'Deep Atlantis',
    type: 'gradient',
    style: {
      backgroundImage: 'linear-gradient(135deg, #06b6d4 0%, #3b82f6 50%, #1d4ed8 100%)'
    },
    description: 'Vibrant turquoise, deep ocean blue, and cobalt'
  },
  {
    id: 'gradient-emerald',
    name: 'Mint Forest',
    type: 'gradient',
    style: {
      backgroundImage: 'linear-gradient(135deg, #34d399 0%, #059669 50%, #064e3b 100%)'
    },
    description: 'Fresh emerald mint and deep forest greens'
  },
  {
    id: 'gradient-sherbet',
    name: 'Peach Sherbet',
    type: 'gradient',
    style: {
      backgroundImage: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 99%, #fecfef 100%)'
    },
    description: 'Soft pastel peach and delightful cherry blossom pink'
  },
  {
    id: 'gradient-lava',
    name: 'Volcanic Glow',
    type: 'gradient',
    style: {
      backgroundImage: 'linear-gradient(135deg, #f97316 0%, #b91c1c 60%, #450a0a 100%)'
    },
    description: 'Fierce orange-red neon glowing magma'
  },
  {
    id: 'solid-dark',
    name: 'Slate Stealth',
    type: 'solid',
    style: {
      backgroundColor: '#1e293b'
    },
    description: 'Clean, professional matte gray-blue solid'
  },
  {
    id: 'solid-light',
    name: 'Snow Alabaster',
    type: 'solid',
    style: {
      backgroundColor: '#f8fafc'
    },
    description: 'Pristine soft white for high-contrast prints'
  },
  {
    id: 'transparent',
    name: 'Transparent Grid',
    type: 'transparent',
    style: {
      backgroundColor: 'transparent'
    },
    description: 'Transparent backdrop with grid markings (ideal for overlays)'
  }
];

export const LANGUAGES: Language[] = [
  {
    id: 'typescript',
    name: 'TypeScript',
    prismId: 'typescript',
    extension: 'ts',
    defaultCode: `// ✨ TypeScript Advanced Type Wizardry
interface User {
  id: string;
  username: string;
  role: 'admin' | 'developer' | 'guest';
  permissions: string[];
}

type ReadOnlyUser<T> = {
  readonly [P in keyof T]: T[P];
};

async function fetchActiveUser(userId: string): Promise<ReadOnlyUser<User>> {
  const response = await fetch(\`/api/users/\${userId}\`);
  const data = await response.json();
  
  return {
    ...data,
    role: data.role ?? 'guest',
    permissions: data.permissions ?? []
  };
}

// Instant activation!
const activeUser = await fetchActiveUser("usr_01H92G7Z");
console.log(\`Welcome back, \${activeUser.username}! ✨\`);`
  },
  {
    id: 'javascript',
    name: 'JavaScript / React',
    prismId: 'javascript',
    extension: 'jsx',
    defaultCode: `import React, { useState, useEffect } from 'react';

// 🚀 A Beautiful React Live Counter Hook
export function CodeGlowCounter({ initialValue = 0 }) {
  const [count, setCount] = useState(initialValue);
  const [status, setStatus] = useState('Idle');

  useEffect(() => {
    if (count > 0 && count % 10 === 0) {
      setStatus('🎉 Decade Milestoned!');
      const timer = setTimeout(() => setStatus('Idle'), 2000);
      return () => clearTimeout(timer);
    }
  }, [count]);

  return (
    <div className="flex flex-col items-center gap-4 p-6 rounded-xl bg-white/5 backdrop-blur-md">
      <h2 className="text-xl font-bold text-purple-400">React Glow Counter</h2>
      <p className="text-sm text-slate-400">Current status: {status}</p>
      <div className="text-4xl font-extrabold">{count}</div>
      <button 
        onClick={() => setCount(prev => prev + 1)}
        className="px-4 py-2 bg-purple-600 rounded-lg hover:bg-purple-500 transition"
      >
        Increment
      </button>
    </div>
  );
}`
  },
  {
    id: 'python',
    name: 'Python (FastAPI)',
    prismId: 'python',
    extension: 'py',
    defaultCode: `from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="CodeGlow API", version="2.0")

class Snippet(BaseModel):
    id: int
    title: str
    code: str
    language: str
    views: Optional[int] = 0

DATABASE = {}

@app.post("/snippets/", response_model=Snippet, status_code=210)
def create_snippet(snippet: Snippet):
    if snippet.id in DATABASE:
        raise HTTPException(status_code=400, detail="Snippet already exists")
    DATABASE[snippet.id] = snippet
    return snippet

@app.get("/snippets/{snippet_id}", response_model=Snippet)
def get_snippet(snippet_id: int):
    snippet = DATABASE.get(snippet_id)
    if not snippet:
        raise HTTPException(status_code=404, detail="Snippet not found")
    # Log access and increment view count
    snippet.views += 1
    return snippet`
  },
  {
    id: 'rust',
    name: 'Rust',
    prismId: 'rust',
    extension: 'rs',
    defaultCode: `// 🦀 Safe and blazing fast Rust concurrency
use std::thread;
use std::time::Duration;

#[derive(Debug)]
struct Worker {
    id: usize,
    status: String,
}

impl Worker {
    fn spawn_task(&self) -> thread::JoinHandle<()> {
        let id = self.id;
        let status = self.status.clone();
        
        thread::spawn(move || {
            println!("🚀 Worker {} initialized with status: {}", id, status);
            thread::sleep(Duration::from_millis(500));
            println!("✅ Worker {} completed its task flawlessly!", id);
        })
    }
}

fn main() {
    let workers = vec![
        Worker { id: 1, status: String::from("Active") },
        Worker { id: 2, status: String::from("Idle") },
    ];

    let handles: Vec<_> = workers.iter()
        .map(|w| w.spawn_task())
        .collect();

    for handle in handles {
        handle.join().unwrap();
    }
    println!("✨ All concurrent workloads discharged successfully!");
}`
  },
  {
    id: 'go',
    name: 'Go',
    prismId: 'go',
    extension: 'go',
    defaultCode: `package main

import (
	"fmt"
	"sync"
	"time"
)

// 🦫 Parallel Processing with Goroutines
func worker(id int, wg *sync.WaitGroup, results chan<- string) {
	defer wg.Done()
	fmt.Printf("Worker %d starting task...\\n", id)
	time.Sleep(time.Millisecond * 400)
	
	results <- fmt.Sprintf("Result from worker %d: Success", id)
}

func main() {
	var wg sync.WaitGroup
	results := make(chan string, 3)

	for i := 1; i <= 3; i++ {
		wg.Add(1)
		go worker(i, &wg, results)
	}

	wg.Wait()
	close(results)

	fmt.Println("📥 Retrieving processed values:")
	for res := range results {
		fmt.Printf("  -> %s\\n", res)
	}
	fmt.Println("✨ Pipeline executed without locks!")
}`
  },
  {
    id: 'html',
    name: 'HTML',
    prismId: 'html',
    extension: 'html',
    defaultCode: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CodeGlow Showcase</title>
  <style>
    .hero {
      background: radial-gradient(circle, #a855f7 0%, #000 100%);
      animation: pulse 10s infinite alternate;
    }
  </style>
</head>
<body>
  <header class="glass-header">
    <h1 class="logo">✨ CodeGlow</h1>
    <nav>
      <a href="#features">Features</a>
      <a href="#pricing" class="btn-premium">Go Pro</a>
    </nav>
  </header>
  <main>
    <section class="hero">
      <h2>Aesthetic Visual Code Snippets</h2>
      <p>Transform standard, boring code blocks into Dribbble-ready images instantly.</p>
    </section>
  </main>
</body>
</html>`
  },
  {
    id: 'css',
    name: 'CSS / Tailwind',
    prismId: 'css',
    extension: 'css',
    defaultCode: `/* 🌀 Pulsing Glassmorphic Card styling */
.glow-card {
  position: relative;
  border-radius: 24px;
  background: rgba(255, 255, 255, 0.03);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  overflow: hidden;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.glow-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: radial-gradient(800px circle at var(--x, 0) var(--y, 0), rgba(168, 85, 247, 0.15), transparent 40%);
  pointer-events: none;
  z-index: 1;
}

.glow-card:hover {
  transform: translateY(-6px) scale(1.02);
  border-color: rgba(168, 85, 247, 0.3);
  box-shadow: 0 30px 60px -15px rgba(168, 85, 247, 0.25);
}`
  },
  {
    id: 'sql',
    name: 'SQL',
    prismId: 'sql',
    extension: 'sql',
    defaultCode: `-- 📊 Analytics: High Performing Developer Sales Query
WITH TopDevelopers AS (
    SELECT 
        dev_id,
        COUNT(snippet_id) as total_snippets,
        SUM(likes_count) as total_likes
    FROM user_snippets
    WHERE created_at >= DATEADD(month, -6, GETDATE())
    GROUP BY dev_id
    HAVING COUNT(snippet_id) >= 10
)
SELECT 
    d.username,
    d.role_title,
    td.total_snippets,
    td.total_likes,
    RANK() OVER (ORDER BY td.total_likes DESC) as ranking_position
FROM TopDevelopers td
JOIN developers d ON d.id = td.dev_id
ORDER BY ranking_position ASC
LIMIT 5;`
  },
  {
    id: 'json',
    name: 'JSON',
    prismId: 'json',
    extension: 'json',
    defaultCode: `{
  "name": "codeglow-beautifier",
  "version": "1.0.0",
  "private": true,
  "author": "Celeste Web Team",
  "config": {
    "theme": "synthwave-glow",
    "fontSize": 15,
    "padding": "64px",
    "borderRadius": "24px",
    "macButtons": true,
    "lineNumbers": true,
    "tiltEnabled": true
  },
  "dependencies": {
    "framer-motion": "^11.0.0",
    "html-to-image": "^1.11.11",
    "lucide-react": "^0.300.0",
    "prismjs": "^1.29.0",
    "react": "^19.0.0"
  }
}`
  }
];
